from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.python import BaseOperator
from airflow.utils.dates import days_ago, datetime

import textwrap
import tasks

default_args = {'owner': 'Serhii Alpatov', 'start_date': days_ago(0), 'depends_on_past': False}

intervals = ['@once', '@hourly','55 17 * * */5']



with DAG("alpatov_test_dag_2", default_args=default_args, schedule_interval=intervals[0],
         catchup=False,tags=['test','dz','files']) as dag:
    task1 = PythonOperator(task_id='Checking_data', python_callable=tasks.check_if_file_empty)
    task2 = BranchPythonOperator(task_id='Decision', python_callable=tasks.result)
    task3 = PythonOperator(task_id='Empty_file', python_callable=tasks.pass_test)
    task4 = PythonOperator(task_id='Not_Empty_file', python_callable=tasks.check_if_file_empty)
    task1.doc_md = textwrap.dedent( """This is good task""")

    task1 >> task2 >> [task3, task4]

    dag.doc_md = __doc__

with DAG("alpatov_test_dag_3", default_args=default_args, schedule_interval=intervals[0],
         catchup=False, tags=['test', 'dz', 'files']) as dag:
    task1 = PythonOperator(task_id='Checking_data', python_callable=tasks.check_if_file_empty)
    task2 = BranchPythonOperator(task_id='Decision', python_callable=tasks.result)
    task3 = PythonOperator(task_id='Empty_file', python_callable=tasks.pass_test)
    task4 = PythonOperator(task_id='Not_Empty_file', python_callable=tasks.check_if_file_empty)
    task1.doc_md = textwrap.dedent("""This is good task""")

    task1 >> task2 >> [task3, task4]

    dag.doc_md = __doc__