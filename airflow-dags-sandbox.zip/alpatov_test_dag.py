# import airflow
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago, datetime

import weather
import pybot

default_args = {'owner': 'Serhii Alpatov', 'start_date': days_ago(0), 'depends_on_past': False}

intervals = ['@once', '@hourly']

with DAG("alpatov_test_dag", default_args=default_args, schedule_interval=intervals[0], catchup=False) as dag:
    task1 = PythonOperator(task_id='Checking_data', python_callable=weather.get_new_data)
    #task2 = PythonOperator(task_id='Reporting', python_callable=pybot.send_message())

