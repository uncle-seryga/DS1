from datetime import timedelta

from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=1),
}

dag_args = {
    'description': 'Test DAG for evaluation KubernetesPodOperator that run image "hello_world"',
    'concurrency': 1,
    'max_active_runs': 1,
    'start_date': days_ago(2),
    'schedule_interval': '0 * * * *',  # every hour
    'catchup': False,
    'tags': ['k8s', 'test'],
}

with DAG('example_KubernetesPod_operator', default_args=default_args, **dag_args) as dag:
    k8_hello_world_task = KubernetesPodOperator(
        namespace='palefat-dev',
        image="hello-world:latest",
        name="kubernetes_hello_world_pod",
        is_delete_operator_pod=True,
        in_cluster=True,
        task_id="k8_hello_world_task_id",
        get_logs=True,
        dag=dag
    )

    k8_hello_world_task
