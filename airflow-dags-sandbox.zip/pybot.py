import telebot

bot = telebot.TeleBot('1767735140:AAH6QBOBiB4ZobDTuxSyIny45ZHmIO_czSU')


@bot.message_handler(commands=['start'])
def add_new_user(mes):
    with open('bot.cfg', mode='wr') as file:
        data = eval(file.read())
        if mes.chat.id not in data:
            data.append(mes.chat.id)
            file.write(str(data))


def send_message():
    with open('bot.cfg', mode='wr') as file:
        data = eval(file.read())
        for x in data:
            bot.send_message(data,'New weather data arrived')
