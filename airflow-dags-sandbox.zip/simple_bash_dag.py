from airflow.utils.dates import days_ago

from airflow import DAG
from airflow.operators.bash import BashOperator

from datetime import timedelta

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=1),
}

dag_args = {
    'description': 'Test DAG for evaluation BashOperator that run echo "Hello Airflow!"',
    'concurrency': 1,
    'max_active_runs': 1,
    'start_date': days_ago(2),
    'schedule_interval': '0 * * * *',  # every hour
    'catchup': False,
    'tags': ['bash', 'test'],
}


with DAG('example_bash_operator', default_args=default_args, **dag_args) as dag:
    bash_task = BashOperator(task_id='bash_task_1',
                             bash_command="ls -al",
                             dag=dag)
    bash_task

