import os
path = os.getcwd()
file = open(path+'/file.txt','w')
def check_if_file_empty():
    file.write('hello')
    print(path)
    a = 'asd'
    if a == '':
        return True
    else:
        return False

def result():
    a = ''
    if a == '':
        return 'Empty_file'
    else:
        return 'Not_Empty_file'

def send_file():
    pass

def pass_test():
    pass