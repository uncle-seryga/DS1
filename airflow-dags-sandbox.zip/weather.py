import requests
import sqlite3
import datetime

api_data = {'key': 'e90fab7014064d2c88795d9fd95afa6f',
            'url_current': 'http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_key}&units=metric'}


def get_weather_state(city):
    try:
        url = api_data['url_current'].format(city_name=city, API_key=api_data['key'])
        data = requests.get(url).text
    except ConnectionRefusedError:
        data = 'Connection was refused by a server'
    return data


def get_new_data():
    now = datetime.datetime.now()
    data = eval(get_weather_state('Kyiv'))
    print(data)

